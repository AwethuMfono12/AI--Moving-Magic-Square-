//Student surname: Mfono
//Student name:  Anovuyo
//Student number: 3947818
//CSC311 2023 AI Practical

package com.company.State;
import java.util.*;


public class State implements Comparable<State>
{
    private int[] board = new int[9];
    private int position9;
    private int[] heuristicVal;

    public State(int[9] board, int position9, int[] heuristicVal){
        this.board = board;
        this.heuristicVal = heuristicVal;
        this.position9 = position9;
    }
    public int[] getBoard() {
        return board;
    }

    public int[] getHeuristicVal() {
        return heuristicVal;
    }

    public int getPosition9() {
        return position9;
    }


    @Override
    public int compareTo(State o) {
        if(heuristicVal == o.heuristicVal) {
            return 0;
        }else if (heuristicVal< o.heuristicVal) {
            return -1;
        }else{
            return 1;
        }
        public int calculateHeuristicVal(int[] board) {

            int row1 = Math.abs ( board[0] + board[1] + board[2] - 15 );
            int row2 = Math.abs ( board[3] + board[4] + board[5] - 15 );
            int row3 = Math.abs ( board[6] + board[7] + board[8] - 15 );

            int RowDiff = row3 + row1 + row2;

            int column1 = Math.abs ( board[0] + board[3] + board[6] - 15 );
            int column2 = Math.abs ( board[1] + board[4] + board[7] - 15 );
            int column3 = Math.abs ( board[2] + board[5] + board[8] - 15 );

            int columnDiff = column1 + column2 + column3;

            int diagonals1 = Math.abs ( board[0] + board[4] + board[8] - 15 );
            int diagonals2 = Math.abs ( board[2] + board[4] + board[6] - 15 );

            int diagonalDiff = diagonals1 + diagonals2;

            return RowDiff + columnDiff + diagonalDiff;

        }
        public List<State> generateSuccessorStates() {
            List<State> successors = new ArrayList<>();
            int row = position9 / 3;
            int col = position9 % 3;
            if (row > 0) { // swap with top
                int[] newBoard = board.clone();
                int index = position9 - 3;
                int temp = newBoard[index];
                newBoard[index] = 9;
                newBoard[position9] = temp;
                successors.add(new State(newBoard));
            }
            if (row < 2) { // swap with bottom
                int[] newBoard = board.clone();
                int index = position9 + 3;
                int temp = newBoard[index];
                newBoard[index] = 9;
                newBoard[position9] = temp;
                successors.add(new State(newBoard));
            }
            if (col > 0) { // swap with left
                int[] newBoard = board.clone();
                int index = position9 - 1;
                int temp = newBoard[index];
                newBoard[index] = 9;
                newBoard[position9] = temp;
                successors.add(new State(newBoard));
            }
            if (col < 2) { // swap with right
                int[] newBoard = board.clone();
                int index = position9 + 1;
                int temp = newBoard[index];
                newBoard[index] = 9;
                newBoard[position9] = temp;
                successors.add(new State(newBoard));
            }

            return successors;
        }
        public State swapWithNine(int i, int j) {
            int[] newBoard = board.clone();
            int temp = newBoard[i];
            newBoard[i] = 9;
            newBoard[j] = temp;
            return new State(newBoard);
        }
        public boolean isGoalState() {
            for (int i = 0; i < board.length - 1; i++) {
                if (board[i] > board[i + 1]) {
                    return false;
                }
                return true;
            }
        }

        public int[] getBoardState() {
            return board;
        }

        public int getHeuristicVal() {
            return new int[]{heuristicVal};
        }
        }
        }


}
