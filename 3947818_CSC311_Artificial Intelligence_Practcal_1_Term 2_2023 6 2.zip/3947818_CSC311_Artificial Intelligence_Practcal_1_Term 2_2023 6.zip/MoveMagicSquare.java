

//Student surname: Mfono
//Student name:  Anovuyo
//Student number: 3947818
//CSC311 2023 AI Practical

import javax.swing.*;
import javax.swing.plaf.nimbus.State;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Set;
import java.util.HashSet;

public class MovingMagicSquare {

    private State initialState;
    private .State goalState;
    private PriorityQueue<State> frontier;
    private Set<State> explored;

    public MovingMagicSquare(String filename) throws FileNotFoundException {
        int[][] board = readBoardFromFile(filename);
        initialState = new State(board);
        goalState = createGoalState(board.length);
        frontier = new PriorityQueue<State>();
        explored = new HashSet<State>();
    }

    private int[][] readBoardFromFile(String filename) throws FileNotFoundException {
        File file = new File(filename);
        Scanner scanner = new Scanner(file);
        int n = scanner.nextInt();
        int[][] board = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                board[i][j] = scanner.nextInt();
            }
        }
        scanner.close();
        return board;
    }

    private State createGoalState(int n) {
        int[][] board = new int[n][n];
        int sum = n * (n * n + 1) / 2;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                board[i][j] = sum - (n * i + j + 1);
            }
        }
        return new State(board) {
            @Override
            protected boolean isInState(JComponent c) {
                return false;
            }
        };
    }

    public boolean solve() {
        frontier.add(initialState);
        while (!frontier.isEmpty()) {
            State state = frontier.poll();
            if (state.equals(goalState)) {
                return true;
            }
            explored.add(state);
            for (State successor : state.generateSuccessors()) {
                if (!explored.contains(successor) && !frontier.contains(successor)) {
                    frontier.add(successor);
                }
            }
        }
        return false;
    }

    public void printState() {
        System.out.println(initialState);
        System.out.println("Heuristic value: " + initialState.getHeuristicVal());
    }

    public static void main(String[] args) {
        try {
            MovingMagicSquare game = new MovingMagicSquare("board.txt");
            if (game.solve()) {
                System.out.println("Solution found:");
                game.printState();
            } else {
                System.out.println("No solution found.");
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }
}


